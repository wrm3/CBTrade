#<=====>#
# Description
#<=====>#

 

#<=====>#
# Known To Do List
#<=====>#



#<=====>#
# Imports
#<=====>#
import time
import os
import re
import sqlparse
import traceback
from datetime import timedelta
from dotenv import load_dotenv

from libs.common import dttm_get
from libs.common import beep

from libs.cls_db_mysql import db_mysql
import pandas as pd
from libs.common import dir_val


#<=====>#
# Variables
#<=====>#
lib_name      = 'bot_db_ohlcv'
log_name      = 'bot_db_ohlcv'


# <=====>#
# Assignments Pre
# <=====>#

# Load environment variables from .env file
load_dotenv()
# Access environment variables
db_host = os.getenv('DB_OHLCV_HOST')
db_port = os.getenv('DB_OHLCV_PORT')
db_name = os.getenv('DB_OHLCV_NAME')
db_user = os.getenv('DB_OHLCV_USER')
db_pw   = os.getenv('DB_OHLCV_PW')

#print(db_host, '-', db_port, '-', db_name, '-', db_user, '-', db_pw)

db_ohlcv = db_mysql(db_host=db_host, db_port=int(db_port), db_name=db_name, db_user=db_user, db_pw=db_pw)


#<=====>#
# Classes
#<=====>#



#<=====>#
# Functions
#<=====>#

def db_safe_string(in_str):
    # Regular expression pattern to match allowed characters
    allowed_chars_pattern = r"[^a-zA-Z0-9\s\.,;:'\"?!@#\$%\^&\*\(\)_\+\-=\[\]\{\}<>\/\\]"
    # Replace characters not in the allowed set with an empty string
    out_str = re.sub(allowed_chars_pattern, '', in_str)
    return out_str

#<=====>#

def db_tbl_del(table_name):
    sql = "delete from {} ".format(table_name)
    db_ohlcv.execute(sql)

#<=====>#

def db_tbl_insupd(table_name, in_data, rat_on_extra_cols_yn='N', exit_on_error=True):
    tbl_cols  = db_ohlcv.table_cols(table=table_name)
    data_cols = []
    ins_data  = []


    if isinstance(in_data, dict):
        if in_data:
            ins_type = 'one'
            if 'add_dttm' in in_data: del in_data['add_dttm']
            if 'dlm' in in_data: del in_data['dlm']
            for k in in_data:
                if k in tbl_cols:
                    data_cols.append(k)
            for k in in_data:
                if k in tbl_cols:
                    ins_data.append(in_data[k])
                else:
                    if rat_on_extra_cols_yn == 'Y':
                        print('column : {} not defined in table {}...'.format(k, table_name))

    # received a list of dictionaries
    elif isinstance(in_data, list):
        ins_data = []
        if in_data:
            if isinstance(in_data[0], dict):
                ins_type = 'many'
                # populating data_cols with all the distinct columns names 
                # from data and checking against table
                for r in in_data:
                    if 'add_dttm' in in_data: del r['add_dttm']
                    if 'dlm' in in_data: del r['dlm']
                    for k in r:
                        if k not in data_cols:
                            if k in tbl_cols:
                                data_cols.append(k)
                            else:
                                if table_name not in ('currs'):
                                    if rat_on_extra_cols_yn == 'Y':
                                        print('column : {} not defined in table {}...'.format(k, table_name))
                # looping through data to standardize for inserts
                for r in in_data:
                    ins_dict = {}
                    # prepopulate with None, which will become null 
                    for k in data_cols: ins_dict[k] = None
                    # assign actual values from data when present
                    for k in r:
                        if k in tbl_cols:
                            ins_dict[k] = r[k]
                    # preparing list of the dict values for the insert
                    ins_list = []
                    for k in data_cols:
                        ins_list.append(ins_dict[k])
                    # adding the row list to the big list for inserts
                    ins_data.append(ins_list)

    sql1 = " insert into {} ( ".format(table_name)

    sql2 = ", ".join(data_cols)

    sql3 = " ) values ( "

    sql4 = ', '.join(['%s'] * len(data_cols))

    sql5 = " ) on duplicate key update  "

    col1 = data_cols[0]
    sql6 = ' {} = values({})'.format(col1, col1)
    for col in data_cols:
        if col != col1:
            sql6 += ', {} = values({})'.format(col, col)

    sql = sql1 + sql2 + sql3 + sql4 + sql5 + sql6


    if table_name == 'mkts' and ins_type == 'one':
        print(f'sql  :')
        formatted_sql = sqlparse.format(sql, reindent=True, keyword_case='upper')
        print(formatted_sql)
        print(f'vals : {ins_data}')

    if ins_type == 'one':
        db_ohlcv.ins_one(sql=sql, vals=ins_data, exit_on_error=exit_on_error)
    else:
        db_ohlcv.ins_many(sql=sql, vals=ins_data, exit_on_error=exit_on_error)


#<=====>#

def db_ohlcv_prod_id_freqs(prod_id):
    prod_id = prod_id.replace('-','_')

    sql = ""
    sql += "select distinct x.freq "
    sql += "  , max(start_dttm) as last_start_dttm "
    sql += "  , UNIX_TIMESTAMP(max(start_dttm)) as last_start_unix "
    sql += f"  from ohlcv_{prod_id} x "
    sql += "  where 1=1 "
    sql += "  group by x.freq "

    last_dttms = db_ohlcv.seld(sql)

    if not last_dttms:
        last_dttms = {}

    return last_dttms

#<=====>#

def db_ohlcv_freq_get(prod_id, freq, lmt=300):
    prod_id = prod_id.replace('-','_')

    sql = ""
    sql += "select * "
    sql += f"  from ohlcv_{prod_id} x "
    sql += f"  where freq = '{freq}' "
    sql += "   order by x.timestamp desc "
    sql += f"  limit {lmt} "

    ohlcv = db_ohlcv.seld(sql)

    if ohlcv:
        newest_timestamp = ohlcv[0]['timestamp']
        oldest_timestamp  = ohlcv[-1]['timestamp']
        newest = ohlcv[0]
        oldest = ohlcv[-1]
#        G(f'found {len(ohlcv)} rows for {prod_id}, freq : {freq}, newest : {newest_timestamp}, oldest : {oldest_timestamp}...')
#    print(newest)
#    print(oldest)
    elif not ohlcv:
        ohlcv = []

    return ohlcv

#<=====>#

def db_check_ohlcv_prod_id_piano(prod_id, in_data):
#    freqs = ['1min','3min','5min','15min','30min','1h','4h','1d']
    freqs = ['1min','5min','15min','30min','1h','4h','1d']

    sql = ''
    sql += 'create table if not exists '
    sql += f'ohlcv_{prod_id}_piano('
    sql += '    prod_id     varchar(64) '
    for freq in freqs:
        sql += '  , timestamp   timestamp '
        sql += '  , freq_{freq}        varchar(64) '
        sql += '  , open_{freq}        decimal(36, 12) '
        sql += '  , high_{freq}        decimal(36, 12) '
        sql += '  , low_{freq}         decimal(36, 12) '
        sql += '  , close_{freq}       decimal(36, 12) '
        sql += '  , volume_{freq}      decimal(36, 12) '
        sql += '  , start_dttm_{freq}  timestamp, '
        sql += '  , end_dttm_{freq}    timestamp '
        sql += '  , upd_dttm_{freq}    timestamp '
        sql += '  , dlm_{freq}         timestamp default current_timestamp on update current_timestamp '                              
    sql += ');'

    db_ohlcv.execute(sql)

#<=====>#

def db_check_ohlcv_prod_id_table(prod_id):
    prod_id = prod_id.replace('-','_')
    table_name = f"ohlcv_{prod_id}"
    
    # First check if the table exists
    sql = f"""
    SELECT COUNT(*) 
    FROM information_schema.TABLES 
    WHERE table_schema = 'ohlcv' 
    AND table_name = '{table_name}'
    """
    table_exists = db_ohlcv.sel(sql) > 0
    
    # Only create the table if it doesn't exist
    if not table_exists:
        print(f"Creating table ohlcv.{table_name}")
        # Create table if not exists
        sql = ""
        sql += "create table if not exists "
        sql += f" ohlcv.{table_name} ("
        sql += "    timestamp   timestamp "
        sql += "  , freq        varchar(64) "
        sql += "  , open        decimal(36, 12) "
        sql += "  , high        decimal(36, 12) "
        sql += "  , low         decimal(36, 12) "
        sql += "  , close       decimal(36, 12) "
        sql += "  , volume      decimal(36, 12) "
        sql += "  , start_dttm  timestamp "
        sql += "  , end_dttm    timestamp "
        sql += "  , upd_dttm    timestamp default current_timestamp on update current_timestamp "
        sql += "  , dlm         timestamp default current_timestamp on update current_timestamp "

        sql += "  , start_unix  bigint default 0 "
        sql += "  , end_unix    bigint default 0 "
        sql += "  , upd_unix    bigint default 0 "
        sql += "  , dlm_unix    bigint default 0 "

        sql += "  , unique(timestamp, freq) "
        sql += "  , INDEX idx_freq_timestamp (freq, timestamp DESC)"
        sql += "  )"
        db_ohlcv.execute(sql)
        
        # Check for insert trigger
        sql = f"""
        SELECT COUNT(*) 
        FROM information_schema.TRIGGERS 
        WHERE event_object_schema = 'ohlcv' 
        AND event_object_table = '{table_name}'
        AND trigger_name = 'before_insert_{table_name}'
        """
        insert_trigger_exists = db_ohlcv.sel(sql) > 0
        
        # Check for update trigger
        sql = f"""
        SELECT COUNT(*) 
        FROM information_schema.TRIGGERS 
        WHERE event_object_schema = 'ohlcv' 
        AND event_object_table = '{table_name}'
        AND trigger_name = 'before_update_{table_name}'
        """
        update_trigger_exists = db_ohlcv.sel(sql) > 0
        
        # Create triggers if they don't exist
        try:
            # Create INSERT trigger if it doesn't exist
            if not insert_trigger_exists:
                print(f"Creating INSERT trigger for {table_name}")
                # Drop existing trigger if it exists (just to be safe)
                sql = f"DROP TRIGGER IF EXISTS before_insert_{table_name}"
                db_ohlcv.execute(sql)
                
                # Create INSERT trigger with Unix-first approach
                sql = f"""
                CREATE TRIGGER before_insert_{table_name} 
                BEFORE INSERT ON {table_name} 
                FOR EACH ROW 
                BEGIN 
                    -- Set Unix timestamp first if not already set
                    IF NEW.start_unix = 0 AND NEW.start_dttm IS NOT NULL THEN
                        SET NEW.start_unix = UNIX_TIMESTAMP(NEW.start_dttm);
                    END IF;
                    
                    IF NEW.end_unix = 0 AND NEW.end_dttm IS NOT NULL THEN
                        SET NEW.end_unix = UNIX_TIMESTAMP(NEW.end_dttm);
                    END IF;
                    
                    IF NEW.upd_unix = 0 AND NEW.upd_dttm IS NOT NULL THEN
                        SET NEW.upd_unix = UNIX_TIMESTAMP(NEW.upd_dttm);
                    END IF;
                    
                    IF NEW.dlm_unix = 0 AND NEW.dlm IS NOT NULL THEN
                        SET NEW.dlm_unix = UNIX_TIMESTAMP(NEW.dlm);
                    END IF;
                    
                    -- Then derive datetime from Unix timestamp
                    IF NEW.start_unix > 0 THEN
                        SET NEW.start_dttm = FROM_UNIXTIME(NEW.start_unix);
                    END IF;
                    
                    IF NEW.end_unix > 0 THEN
                        SET NEW.end_dttm = FROM_UNIXTIME(NEW.end_unix);
                    END IF;
                    
                    IF NEW.upd_unix > 0 THEN
                        SET NEW.upd_dttm = FROM_UNIXTIME(NEW.upd_unix);
                    END IF;
                    
                    IF NEW.dlm_unix > 0 THEN
                        SET NEW.dlm = FROM_UNIXTIME(NEW.dlm_unix);
                    END IF;
                END
                """
                db_ohlcv.execute(sql)
            
            # Create UPDATE trigger if it doesn't exist
            if not update_trigger_exists:
                print(f"Creating UPDATE trigger for {table_name}")
                # Drop existing trigger if it exists (just to be safe)
                sql = f"DROP TRIGGER IF EXISTS before_update_{table_name}"
                db_ohlcv.execute(sql)
                
                # Create UPDATE trigger with Unix-first approach
                sql = f"""
                CREATE TRIGGER before_update_{table_name} 
                BEFORE UPDATE ON {table_name} 
                FOR EACH ROW 
                BEGIN 
                    -- Set Unix timestamp first if not already set
                    IF NEW.start_unix = 0 AND NEW.start_dttm IS NOT NULL THEN
                        SET NEW.start_unix = UNIX_TIMESTAMP(NEW.start_dttm);
                    END IF;
                    
                    IF NEW.end_unix = 0 AND NEW.end_dttm IS NOT NULL THEN
                        SET NEW.end_unix = UNIX_TIMESTAMP(NEW.end_dttm);
                    END IF;
                    
                    IF NEW.upd_unix = 0 AND NEW.upd_dttm IS NOT NULL THEN
                        SET NEW.upd_unix = UNIX_TIMESTAMP(NEW.upd_dttm);
                    END IF;
                    
                    IF NEW.dlm_unix = 0 AND NEW.dlm IS NOT NULL THEN
                        SET NEW.dlm_unix = UNIX_TIMESTAMP(NEW.dlm);
                    END IF;
                    
                    -- Then derive datetime from Unix timestamp
                    IF NEW.start_unix > 0 THEN
                        SET NEW.start_dttm = FROM_UNIXTIME(NEW.start_unix);
                    END IF;
                    
                    IF NEW.end_unix > 0 THEN
                        SET NEW.end_dttm = FROM_UNIXTIME(NEW.end_unix);
                    END IF;
                    
                    IF NEW.upd_unix > 0 THEN
                        SET NEW.upd_dttm = FROM_UNIXTIME(NEW.upd_unix);
                    END IF;
                    
                    IF NEW.dlm_unix > 0 THEN
                        SET NEW.dlm = FROM_UNIXTIME(NEW.dlm_unix);
                    END IF;
                END
                """
                db_ohlcv.execute(sql)
        except Exception as e:
            # Check if the error is "Trigger already exists"
            if isinstance(e, Exception) and "Trigger already exists" in str(e):
                # Trigger already exists, which is fine
                pass
            else:
                # Some other error occurred, re-raise it
                raise e

    time.sleep(0.05)


#<=====>#

def db_tbl_ohlcv_prod_id_insupd(prod_id, freq, in_df):
    prod_id = prod_id.replace('-','_')

    in_df['freq'] = freq

    in_df['start_dttm'] = in_df.index
    if freq == '1min':
        in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=59) 
#    elif freq == '3min':
#        in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=179) 
    elif freq == '5min':
        in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=299) 
    elif freq == '15min':
        in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=899) 
    elif freq == '30min':
        in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=1799) 
    elif freq == '1h':
        in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=3599) 
    elif freq == '4h':
        in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=14399) 
    elif freq == '1d':
        in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=86399) 
    
    # Add Unix timestamps for more accurate time handling
    if 'timestamp_unix' in in_df.columns:
        # Use existing timestamp_unix column
        in_df['start_unix'] = in_df['timestamp_unix']
    else:
        # Convert datetime to Unix timestamp
        in_df['start_unix'] = in_df['start_dttm'].astype('int64') // 10**9
    
    # Calculate end_unix based on frequency
    if freq == '1min':
        in_df['end_unix'] = in_df['start_unix'] + 59
#    elif freq == '3min':
#        in_df['end_unix'] = in_df['start_unix'] + 179
    elif freq == '5min':
        in_df['end_unix'] = in_df['start_unix'] + 299
    elif freq == '15min':
        in_df['end_unix'] = in_df['start_unix'] + 899
    elif freq == '30min':
        in_df['end_unix'] = in_df['start_unix'] + 1799
    elif freq == '1h':
        in_df['end_unix'] = in_df['start_unix'] + 3599
    elif freq == '4h':
        in_df['end_unix'] = in_df['start_unix'] + 14399
    elif freq == '1d':
        in_df['end_unix'] = in_df['start_unix'] + 86399

    in_data = in_df.reset_index().rename(columns={'index': 'timestamp'}).to_dict(orient='records')

    table_name = f'ohlcv_{prod_id}'

    try:
        db_tbl_insupd(table_name, in_data, exit_on_error=False)
    except Exception as e:
        print(dttm_get())
        traceback.print_exc()
        traceback.print_stack()
        print(type(e))
        print(e)
        beep()


#<=====>#

def db_tbl_ohlcv_prod_id_insupd_many(prod_id, in_dfs):
    prod_id = prod_id.replace('-','_')

    all_data = []

    for rfreq in in_dfs:
        msg = f'inserting into ohlcv {prod_id} {rfreq}'

        in_df = in_dfs[rfreq] 

        in_df['freq'] = rfreq

        in_df['start_dttm'] = in_df.index
        if rfreq == '1min':
            in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=59) 
#        elif rfreq == '3min':
#            in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=179) 
        elif rfreq == '5min':
            in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=299) 
        elif rfreq == '15min':
            in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=899) 
        elif rfreq == '30min':
            in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=1799) 
        elif rfreq == '1h':
            in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=3599) 
        elif rfreq == '4h':
            in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=14399) 
        elif rfreq == '1d':
            in_df['end_dttm'] = in_df['start_dttm'] + timedelta(seconds=86399) 

        in_data = in_df.reset_index().rename(columns={'index': 'timestamp'}).to_dict(orient='records')
        all_data.extend(in_data)

    try:
        table_name = f'ohlcv_{prod_id}'
        db_tbl_insupd(table_name, all_data, exit_on_error=False)
    except Exception as e:
        print(dttm_get())
        traceback.print_exc()
        traceback.print_stack()
        print(type(e))
        print(e)
        beep()


#<=====>#

# => mkt_perf_get
def db_ohlcv_table_names_get():
    sql = ""
    sql += "SELECT CONCAT(table_schema, '.', table_name) as table_name "
    sql += "FROM information_schema.TABLES "
    sql += "WHERE table_schema IN ('ohlcv') "
    sql += "GROUP BY table_schema, table_name "
    results = db_ohlcv.seld(sql)
    table_names = [row['table_name'] for row in results]
    return table_names

#<=====>#

def db_ohlcv_dump(prod_id, freq='1min'):

    temp_prod_id = prod_id.replace('-','_')

    table_name = f"ohlcv.ohlcv_{temp_prod_id}"

    sql = ""
    sql += f"select timestamp, freq, open, high, low, close, volume, start_dttm, end_dttm, upd_dttm, dlm "
    sql += f"  from {table_name}"
    sql += f"  where freq = '{freq}'"
    print(sql)
    res = db_ohlcv.seld(sql)
    df = pd.DataFrame(res)
    csv_fname = f'ohlcv/{table_name}_table.csv'
    dir_val(csv_fname)
    df.to_csv(csv_fname, index=True)
    print(f'{csv_fname:<60} saved...')


#<=====>#
# Post Variables
#<=====>#



#<=====>#
# Default Run
#<=====>#



#<=====>#
